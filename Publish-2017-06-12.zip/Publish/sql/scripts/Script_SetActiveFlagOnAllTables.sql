-- set new Active flag on all tables.
update Center set Active=1
update Child set Active=1
update Company set Active=1
update Family set Active=1
update Staff set Active=1
update StaffType set Active=1
update Task set Active=1
update UserLogon set Active=1
update Volunteer set Active=1
update VolunteerType set Active=1